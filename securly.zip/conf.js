var checkClusterURL = "http://www.securly.com";

var DEBUG_userEmail = "amar@securlyqa1.com";
var forceUserEmail = false;

var DEBUG_clusterUrl = "http://stagwww.securly.com/crextn";
var forceClusterUrl = false;

var iwfEncodeStep = 3;